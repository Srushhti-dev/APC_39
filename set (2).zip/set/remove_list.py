#8.	Create a list containing duplicate numbers, use a set to remove the duplicates.
numbers = {10, 20, 20, 30, 40, 40, 50}

unique_numbers = set(numbers)

print("Without duplicates:", unique_numbers)